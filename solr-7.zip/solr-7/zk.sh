#!/bin/bash

SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

function start() {
    pushd $BASE_DIR/_app/zookeeper1
	./bin/zkServer.sh start
    popd


    pushd $BASE_DIR/_app/zookeeper2
	./bin/zkServer.sh start
    popd
}


function stop() {
    pushd $BASE_DIR/_app/zookeeper1
	./bin/zkServer.sh stop
    popd


    pushd $BASE_DIR/_app/zookeeper2
	./bin/zkServer.sh stop
    popd
}

function zkcli() {
    pushd $BASE_DIR/_app/zookeeper1
	./bin/zkCli.sh
    popd
}

$1 $2 $3 $4 $5 $6 $7 $8 $9


