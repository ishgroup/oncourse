(function($) {
	$(document).ready(function() {
		$('#nav >ul>li>ul').has('li').parent().addClass('hasChild');
		$(document).on('click', '.nav-toggle', function(e) {
			e.preventDefault();
			$('.navbar.mobile-enabled #nav').slideToggle();
		});

		enquire.register("screen and (max-width: 992px)", {
			setup: function() {
				$(document).on('click', '#nav >ul.hoverOff>li.hasChild>a', function(e) {
					e.preventDefault();
					var _parent = $(this).parent();
					if(!_parent.hasClass('opened')) {
						$('#nav >ul>li').removeClass('opened');
						$('#nav >ul>li>ul').attr('style', '');

						_parent.find('>ul').slideToggle();
						_parent.addClass('opened');
					} else {
						_parent.find('>ul').slideToggle();
						$('#nav >ul>li').removeClass('opened');
					}
				});

				$(document).on('click', '.header-search-toggle.hoverOff', function(e) {
					e.preventDefault();
					$('#search_box').toggleClass('active');
					$('#advanced_search').slideToggle();
					$(this).toggleClass('is-active');
				});
			},
			match: function() {
				$('#nav>ul.list-horizontal').addClass('hoverOff');
				$('.header-search-toggle').addClass('hoverOff');
				$('#advanced_search').css('display', 'none');
			},
			unmatch: function() {
				$('#nav').attr('style', '');
				$('#nav>ul.list-horizontal').removeClass('hoverOff');
				$('#nav >ul>li').removeClass('opened');
				$('#nav >ul>li>ul').attr('style', '');

				$('.header-search-toggle').removeClass('hoverOff is-active');
				$('#search_box').removeClass('active');
				$('#advanced_search').css('display', 'none');
			}
		}, true);

		jQuery('.home-slider > ul').bxSlider({
			mode: 'horizontal',
			captions: true,
			auto: true,
			pause: 5000
		});

		$('.courseTestimonials > ul > li').each(function(indx, item) {
			var ratingBlock = $(item).find('.testimonial-rating');
			var rating = ratingBlock.attr('rating');
			if(rating) {
				ratingBlock.find('>span').removeClass('checked');
				for(var i=0;i<rating;i++) {
					ratingBlock.find('>span:eq('+ i +')').addClass('checked');
				}
			}
		});

		$('.courseTestimonials > ul').bxSlider({
			mode: 'fade',
			captions: true,
			auto: true,
			pause: 5000
		});

		$('.tutors-wrapper.tutors-slider > .tutors-list').bxSlider({
			mode: 'horizontal',
			wrapperClass: "bx-wrapper bx-inverse",
			captions: true,
			auto: true,
			pause: 5000,
			minSlides: 1,
			maxSlides: 2,
			slideWidth: 416.5
		});

		$('.quicklinks').append('<ul class="top-menu"></ul>');
		$('.navbar.mobile-enabled .site-nav>ul>li>a').each(function(key, value) {
			$('.quicklinks>.top-menu').append('<li><a href="'+ $(value).attr('href') +'">'+ $(value).text() +'</a></li>');
		});

		$('.starting-soon ul.courseList>ul>li').each(function(key, value) {
			var href = $(this).find('>a').attr('href');
			var link = '<a href="'+ href +'" class="course-more-link">More Info &gt;</a>';
			$(this).append(link);
		});
	})
})(jQuery);
