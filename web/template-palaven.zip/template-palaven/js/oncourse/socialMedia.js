// Addthis configuration options

var addthis_config = {
	"data_track_addressbar":false,
	"services_exclude": 'print',
	"data_track_clickback": false
};
